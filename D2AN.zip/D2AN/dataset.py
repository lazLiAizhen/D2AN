import os
from utils import *
import torch
import numpy as np
import torch
import  random
from torch.utils.data import DataLoader, Dataset
def seed_everything(seed=0):
    '''
    设置整个开发环境的seed
    :param seed:
    :param device:
    :return:
    '''
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything(0)

def preprocess(args):#预处理
    dataset_path = args.dataset_path  #"../processed_data/"
    print("dataset_path: ", dataset_path)
    # normcounts = pd.read_csv(dataset_path + 'pbmc_expression.csv', index_col=0)  #
    # labels = pd.read_csv(dataset_path + 'pbmc_labels.csv', index_col=0)
    # domain_labels = pd.read_csv(dataset_path + 'batch_labels.csv', index_col=0,dtype={'batch':str})#!!!!
    # data_set = {'features': normcounts.values, 'labels': labels.iloc[:, 0].values,
    #            'accessions': domain_labels.iloc[:, 0].values}#数据集字典（特征、cell标签、域标签：mouse、human）

    print('loading dataset: %s' % args.dataset_name)
    if args.dataset_name == 'pbmc_':
        if args.dataselect == 0:
            all_set = np.load(os.path.join(args.dataset_path, 'pbmc_.npz'), allow_pickle=True)  ###allow_pickle参数
            args.train_set = {'features': all_set['features'][8098:], 'labels': all_set['labels'][8098:],
                              'accessions': all_set['accessions'][8098:]}
            args.test_set = {'features': all_set['features'][:8098], 'labels': all_set['labels'][:8098],
                             'accessions': all_set['accessions'][:8098]}  # 理解为1个batch--->目标域？测试
        if args.dataselect == 1:
            all_set = np.load(os.path.join(args.dataset_path, 'pbmc_.npz'), allow_pickle=True)  ###allow_pickle参数
            args.train_set = {'features': all_set['features'][:8098], 'labels': all_set['labels'][:8098],
                              'accessions': all_set['accessions'][:8098]}
            args.test_set = {'features': all_set['features'][8098:], 'labels': all_set['labels'][8098:],
                             'accessions': all_set['accessions'][8098:]}  #

    elif args.dataset_name == 'pancreas_':  # 1-2
        all_set = np.load(os.path.join(args.dataset_path, 'original_pancreas.npz'), allow_pickle=True)  ###allow_pickle参数
        if args.dataselect == 0:
            args.train_set = {'features': all_set['features'][1004:], 'labels': all_set['labels'][1004:],
                              'accessions': all_set['accessions'][1004:]}
            args.test_set = {'features': all_set['features'][:1004], 'labels': all_set['labels'][:1004],
                             'accessions': all_set['accessions'][:1004]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 1:
            args.train_set = {
                'features': np.concatenate((all_set['features'][:1004], all_set['features'][3289:]), axis=0),
                'labels': np.concatenate((all_set['labels'][:1004], all_set['labels'][3289:]), axis=0),
                'accessions': np.concatenate((all_set['accessions'][:1004], all_set['accessions'][3289:]), axis=0)}
            args.test_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                             'accessions': all_set['accessions'][1004:3289]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 2:
            args.train_set = {
                'features': np.concatenate((all_set['features'][:3289], all_set['features'][3927:]), axis=0),
                'labels': np.concatenate((all_set['labels'][:3289], all_set['labels'][3927:]), axis=0),
                'accessions': np.concatenate((all_set['accessions'][:3289], all_set['accessions'][3927:]), axis=0)}
            args.test_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                             'accessions': all_set['accessions'][3289:3927]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 3:
            args.train_set = {'features': all_set['features'][:3927], 'labels': all_set['labels'][:3927],
                              'accessions': all_set['accessions'][:3927]}
            args.test_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                             'accessions': all_set['accessions'][3927:]}
    elif args.dataset_name.startswith('original_pancreas_single'):  # 封装胰腺单对单数据集划分
        all_set = np.load(os.path.join(args.dataset_path, 'original_pancreas.npz'), allow_pickle=True)  ###allow_pickle参数
        if args.dataselect == 12:  # 12代表batch1和batch2  即batch1--->batch2
            args.train_set = {'features': all_set['features'][:1004], 'labels': all_set['labels'][:1004],
                              'accessions': all_set['accessions'][:1004]}
            args.test_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                             'accessions': all_set['accessions'][1004:3289]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 13:
            args.train_set = {'features': all_set['features'][:1004], 'labels': all_set['labels'][:1004],
                              'accessions': all_set['accessions'][:1004]}
            args.test_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                             'accessions': all_set['accessions'][3289:3927]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 14:
            args.train_set = {'features': all_set['features'][:1004], 'labels': all_set['labels'][:1004],
                              'accessions': all_set['accessions'][:1004]}
            args.test_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                             'accessions': all_set['accessions'][3927:]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 21:
            args.train_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                              'accessions': all_set['accessions'][1004:3289]}
            args.test_set = {'features': all_set['features'][1004:], 'labels': all_set['labels'][1004:],
                             'accessions': all_set['accessions'][1004:]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 23:
            args.train_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                              'accessions': all_set['accessions'][1004:3289]}
            args.test_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                             'accessions': all_set['accessions'][3289:3927]}
        elif args.dataselect == 24:
            args.train_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                              'accessions': all_set['accessions'][1004:3289]}
            args.test_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                             'accessions': all_set['accessions'][3927:]}
        elif args.dataselect == 31:
            args.train_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                              'accessions': all_set['accessions'][3289:3927]}
            args.test_set = {'features': all_set['features'][1004:], 'labels': all_set['labels'][1004:],
                             'accessions': all_set['accessions'][1004:]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 32:
            args.train_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                              'accessions': all_set['accessions'][3289:3927]}
            args.test_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                             'accessions': all_set['accessions'][1004:3289]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 34:
            args.train_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                              'accessions': all_set['accessions'][3289:3927]}
            args.test_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                             'accessions': all_set['accessions'][3927:]}
        elif args.dataselect == 41:
            args.train_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                              'accessions': all_set['accessions'][3927:]}
            args.test_set = {'features': all_set['features'][1004:], 'labels': all_set['labels'][1004:],
                             'accessions': all_set['accessions'][1004:]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 42:
            args.train_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                              'accessions': all_set['accessions'][3927:]}
            args.test_set = {'features': all_set['features'][1004:3289], 'labels': all_set['labels'][1004:3289],
                             'accessions': all_set['accessions'][1004:3289]}  # 理解为1个batch--->目标域？测试
        elif args.dataselect == 43:
            args.train_set = {'features': all_set['features'][3927:], 'labels': all_set['labels'][3927:],
                              'accessions': all_set['accessions'][3927:]}
            args.test_set = {'features': all_set['features'][3289:3927], 'labels': all_set['labels'][3289:3927],
                             'accessions': all_set['accessions'][3289:3927]}
    else:
        print('Wrong name, cannot find the dataset.')

        # return data_set
    return args.train_set,args.test_set

def prepare_siamese(args,train_set):
    args._train_X=train_set['features']
    args._train_y=train_set['labels']
    args.accessions_set = list(set(train_set['accessions']))
    args._train_acc = np.array([args.accessions_set.index(item) for item in list(args.train_set['accessions'])])
    args.labels_set = np.unique(args._train_y)  # np.unique() 函数去除其中重复的元素 ，并按元素由小到大返回  得到不重复且排序的cell标签
    args.label_to_indices = {label: np.where(args._train_y == label)[0]
                             for label in args.labels_set}  # 标签对应的索引位置
    args._train_X2 = np.zeros(args._train_X.shape)  # 给定维度的全零数组。
    args._train_z = np.zeros(args._train_acc.shape, dtype=int)
    # args._use_domain = np.ones(args._train_acc.shape)  # not using domain info if the label and domain both occur once
    for index in range(args._train_X.shape[0]):
        label = args._train_y[index]  # cell标签
        # accession = args._train_acc[index]  # batch标签
        negative_ids = np.where(args._train_y != label)[0]  # 按照batch 划分负样例
        positive_ids = np.where(args._train_y == label)[0]
        if np.random.random() > 0.5 and len(positive_ids) >= 1:  # 0-1随机float数
            siamese_index = np.random.choice(positive_ids)  # 从这个ndarray，但必须是一维的)中随机抽取数字，并组成指定大小(size)的数组-----随机抽取一个
            args._train_X2[index] = args._train_X[siamese_index]
            args._train_z[index] = 1
        elif len(negative_ids) >= 1:
            siamese_index = np.random.choice(negative_ids)
            args._train_X2[index] = args._train_X[siamese_index]
            args._train_z[index] = 0
        else:
            args._use_domain[index] = 0
        return args._train_X2,args._train_z


class MyDataset_source(Dataset):
    def __init__(self,data_X,label_y,x2,z):
        super(MyDataset_source, self).__init__()
        self.X, self.y =data_X,label_y
        self.X2,self.Z=x2,z
        print(self.X.shape)

    def __iter__(self):
        return list(zip(self.X, self.y,self.X2,self.Z))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, item):
        return item, self.X[item], self.y[item],self.X2[item],self.Z[item]

class MyDataset_target(Dataset):
    def __init__(self,data_X,label_y):
        super(MyDataset_target, self).__init__()
        self.X, self.y =data_X,label_y
        print(self.X.shape)

    def __iter__(self):
        return list(zip(self.X, self.y))

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, item):
        return item, self.X[item], self.y[item]



def get_dataloader(args):
    train_set, test_set = preprocess(args)
    train_X2_fetures, train_z = prepare_siamese(args, train_set)

    source_dataset=MyDataset_source(torch.FloatTensor(train_set['features']),
        torch.LongTensor(matrix_one_hot(train_set['labels'], int(max(train_set['labels']) + 1)).long()),
        torch.FloatTensor(train_X2_fetures), torch.FloatTensor(train_z)) ####x1,y,x2,z
    target_dataset=MyDataset_target(torch.FloatTensor(test_set['features']),
                              torch.LongTensor(matrix_one_hot(test_set['labels'],int(max(test_set['labels']) + 1)).long()))
    return source_dataset,target_dataset


