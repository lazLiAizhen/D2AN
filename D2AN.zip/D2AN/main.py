import argparse#参数解析 #1、引入模块
import os
import numpy as np
import torch
import  random
from dataset import preprocess
from dataset import get_dataloader
from D2AN import D2AN
def seed_everything(seed=666):
    '''
    设置整个开发环境的seed
    :param seed:
    :param device:
    :return:
    '''
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed_everything(666)

if __name__ == "__main__":
    seed_everything(666)
    parser = argparse.ArgumentParser(
        description='scDRLN: Domain adversarial representation learning Network')  # 2、建立解析对象
    parser.add_argument('--batch_size', type=int, default=256,
                        help='batch_size')  # 256  #3、增加属性：给xx实例增加一个aa属性 # xx.add_argument("aa")
    parser.add_argument('--embedding_size', type=int, default=256, help='embedding_size')  # 256   100
    parser.add_argument('--source_name', type=str, default='pancreas_')#'pancreas_'
    parser.add_argument('--target_name', type=str, default='3')
    parser.add_argument('--dataset_name', type=str, default='pancreas_')  # _single     'pancreas_'
    parser.add_argument('--dataselect', type=int, default=3)
    parser.add_argument('--result_path', type=str, default='./results/')
    parser.add_argument('--dataset_path', type=str, default='./processed_data/')
    parser.add_argument('--num_iterations', type=int, default=50010, help="num_iterations")  # 50010  3010
    # parser.add_argument('--centerloss_coeff', type=float, default=1.0,
    #                     help='regularization coefficient for center loss')  # 中心损失正则化系数#2.0  1.0
    parser.add_argument('--centroid_coeff', type=float, default=1.0,
                        help='regularization coefficient for semantic loss')  # 语义损失正则化系数 #2.0 1.5
    parser.add_argument('--DA_coeff', type=float, default=0.01,
                        help="regularization coefficient for domain alignment loss")  # 域对齐损失正则化系数 #1.0  #0.8
    parser.add_argument('--DR_coeff', type=float, default=0.0001,
                        help="regularization coefficient for domain reconstruction loss")  # 目标域重建正则化系数 #0.01
    # parser.add_argument('--ls_m', type=float, default=0.1,
    #                     help="regularization coefficient for source margin loss")  # 源域margin对齐#对比损失正则化系数
    parser.add_argument('-m', '--margin', type=float, default=1.0,
                        help='margin of contrastive loss')#1.0
    parser.add_argument('--cell_th', type=int, default=20, help='cell_th')
    parser.add_argument('--epoch_th', type=int, default=15000, help='epoch_th')  # 15000  1000
    parser.add_argument('--gpu_id', type=str, nargs='?', default='0', help="device id to run")
    parser.add_argument('-c', '--ckpts', type=str, default='ckpts/', help='model checkpoints path')
    parser.add_argument("-o", "--output", type=str, default='original_pancreas_single',
                        help='Save model filepath')  # scquery
    parser.add_argument('--lm_coeff', type=float, default=1.0,
                        help="regularization coefficient for contrastive loss")#0.0001


    parser.add_argument('--BNM_coeff', type=float, default=0.2, help="regularization coefficient for BNM loss")  #
    parser.add_argument('--alpha', type=float, default=1.0, metavar='ALPHA',
                        help='regularization coefficient for VAT loss')  # VAT损失正则化系数
    parser.add_argument('--xi', type=float, default=10.0, metavar='XI',
                        help='hyperparameter of VAT')
    parser.add_argument('--eps', type=float, default=1.0, metavar='EPS',
                        help='hyperparameter of VAT')
    parser.add_argument('--ip', type=int, default=1, metavar='IP',
                        help='hyperparameter of VAT')


    args = parser.parse_args()  # 4、属性给与args实例：add_argument 返回到 args 子类实例
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu_id  # '0,1,2,3'
    print(args)

    torch.cuda.empty_cache()  # 释放显存

    train_set, test_set = preprocess(args)  ###!
    source_dataset, target_dataset = get_dataloader(args)
    # print(source_dataset,test_dataset)

    # scDRLN(args, train_set, test_set)
    if not os.path.exists(args.ckpts):
        os.mkdir(args.ckpts)

    model_path = os.path.join(args.ckpts, args.output)  # os.path.join()函数用于路径拼接文件路径，可以传入多个路径
    if not os.path.exists(model_path):
        os.mkdir(model_path)

    log_file = 'dataset.%s_output%s_dataselect%d_lambda%.2f_lm_coeff%.2f_semantic%.2f_reconstruct%.2f_epoch%d_batch_size%d.txt' \
               % (args.dataset_name, args.output, args.dataselect, args.DA_coeff, args.lm_coeff,
                  args.centroid_coeff, args.DR_coeff, args.num_iterations, args.batch_size)
    with open(os.path.join(args.ckpts, args.output, log_file), 'w') as fw:
             D2AN(args, train_set, test_set, source_dataset, target_dataset, fw)






