import numpy as np
import scanpy as sc
all_set = np.load(r'D:\scDRLN-masters\processed_data\original_pancreas.npz', allow_pickle=True)  ###allow_pickle参数
train_set = {'features': all_set['features'][1004:], 'labels': all_set['labels'][1004:],
                              'accessions': all_set['accessions'][1004:]}
test_set = {'features': all_set['features'][:1004], 'labels': all_set['labels'][:1004],
                             'accessions': all_set['accessions'][:1004]}  # 理解为1个batch--->目标域？测试

adata1=sc.AnnData(train_set['features'])
adata1.obs['batch']=train_set['accessions'].astype(str)
adata1.obs['BATCH']=train_set['accessions'].astype(str)

adata2=sc.AnnData(test_set['features'])
adata2.obs['batch']=test_set['accessions'].astype(str)
adata2.obs['BATCH']=test_set['accessions'].astype(str)

adata=sc.AnnData.concatenate(adata1,adata2,batch_key='BATCH')
print(set(adata1.obs['batch']))
print(set(adata2.obs['batch']))
# print(adata.obs['batch'])
print(set(adata.obs['batch']))
print(type(test_set['accessions']))
test_set['accessions'].astype(str)
print(set(test_set['accessions'].astype(str)))
