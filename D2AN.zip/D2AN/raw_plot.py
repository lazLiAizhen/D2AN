import os

# import pylab as pl

os.environ['PYTHONHASHSEED'] = '0'

# import pandas as pd
# import numpy as np
import scanpy as sc
# import matplotlib
# # matplotlib.use('TkAgg')
# import matplotlib.pyplot as plt

# from time import time
# import sys
# import matplotlib
# import matplotlib.pyplot as plt
# # %matplotlib inline
# # sc.settings.set_figure_params(dpi=300)
# import tensorflow as tf
# import keras
#
# import matplotlib as mpl
# import matplotlib.pyplot as plt
# mpl.use("TkAgg")
#
import  random
random.seed(666)
adata=sc.read(r'D:\data\PBMC_merged.h5ad')
print(adata)
# a_train=adata[adata.obs['batch']=='1']
# a_test=adata[adata.obs['batch']=='0']


# 可视化
color_dict = {'B cell': '#1f77b4', 'CD4 T cell':  '#ff7f0e', 'CD8 T cell': '#2ca02c',
              'Hematopoietic stem cell':'#d62728','Megakaryocyte':'#9467bd','Monocyte_CD14':'#8c564b',
              'Monocyte_FCGR3A':'#e377c2','NK cell':'#7f7f7f','Plasmacytoid dendritic cell':'#bcbd22'}

sc.tl.pca(adata)#
sc.pp.neighbors(adata)
sc.tl.umap(adata)
adata.obs['batch'] = ['10X 3\'' if i == '0' else '10X 5\'' for i in adata.obs['batch']]
fig1=sc.pl.umap(adata, color='batch', return_fig=True, title="", legend_loc="", frameon=False)#,legend_fontoutline=True, legend_fontsize= 8
fig1.savefig('raw_batch.png', dpi=1000, format='png',bbox_inches='tight')
fig2=sc.pl.umap(adata, color='Cell type', return_fig=True,palette=color_dict, title="", legend_loc="", frameon=False)
fig2.savefig('raw_celltype.png', dpi=1000,bbox_inches='tight', format='png')
# pl.show()

import scanpy as sc

#
# 画 UMAP 图并设置颜色
# 查看颜色设置



# import numpy as np
# from evaluate2 import evaluate_summary, evaluate_multibatch
# all_set = np.load(r'D:\scDRLN-master\scDRLN\processed_data\pbmc_.npz', allow_pickle=True)  ###allow_pickle参数
# train_set = {'features': all_set['features'][8098:], 'labels': all_set['labels'][8098:],
#                               'accessions': all_set['accessions'][8098:]}
# test_set = {'features': all_set['features'][:8098], 'labels': all_set['labels'][:8098],
#                              'accessions': all_set['accessions'][:8098]}  # 理解为1个batch--->目标域？测试
#
# div_score, div_score_all, ent_score, sil_score = evaluate_multibatch(adata.to_df().values, test_set, train_set)#, epoch
#
# print("Done!")